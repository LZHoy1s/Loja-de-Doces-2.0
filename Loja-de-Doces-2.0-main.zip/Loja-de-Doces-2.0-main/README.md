# Loja-de-Doces-2.0
Uma leve descrição de uma verdadeira loja de doces
